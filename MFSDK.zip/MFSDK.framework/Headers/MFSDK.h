//
//  MFSDK.h
//  MFSDK
//
//  Created by Sandeep on 22/11/17.
//  Copyright © 2017 Sandeep. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for MFSDK.
FOUNDATION_EXPORT double MFSDKVersionNumber;

//! Project version string for MFSDK.
FOUNDATION_EXPORT const unsigned char MFSDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <MFSDK/PublicHeader.h>


